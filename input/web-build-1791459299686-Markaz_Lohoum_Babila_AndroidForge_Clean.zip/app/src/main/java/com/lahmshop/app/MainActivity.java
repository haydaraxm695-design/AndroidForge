package com.lahmshop.app;

import android.app.*;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.*;
import android.widget.*;
import java.util.*;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.*;

public class MainActivity extends Activity {
    FirebaseFirestore db;
    FirebaseAuth auth;
    ListenerRegistration productsListener;
    boolean firebaseReady = false;
    LinearLayout list;
    ArrayList<Product> products = new ArrayList<>();
    final int RED = Color.rgb(170, 20, 25);
    final int LIGHT = Color.rgb(255, 245, 240);

    int dp(float x){ return (int)(x*getResources().getDisplayMetrics().density+.5f); }

    TextView tv(String s, float size, boolean bold){
        TextView t=new TextView(this);
        t.setText(s); t.setTextSize(size);
        t.setTextColor(Color.rgb(45,45,45));
        t.setGravity(Gravity.RIGHT);
        t.setPadding(dp(10),dp(8),dp(10),dp(8));
        if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        return t;
    }

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        db = FirebaseFirestore.getInstance();
        auth = FirebaseAuth.getInstance();
        firebaseReady = true;
        listenProducts();
    }

    void listenProducts(){
        if(!firebaseReady){
            seed();
            showCustomer();
            return;
        }
        if(productsListener != null) productsListener.remove();
        productsListener = db.collection("products")
            .orderBy("name")
            .addSnapshotListener((snap, e) -> {
                if(e != null || snap == null){
                    if(products.isEmpty()) seed();
                    showCustomer();
                    return;
                }
                products.clear();
                for(DocumentSnapshot d : snap.getDocuments()){
                    String name=d.getString("name");
                    String unit=d.getString("unit");
                    Double price=d.getDouble("price");
                    Boolean offer=d.getBoolean("offer");
                    if(name != null && price != null)
                        products.add(new Product(d.getId(), name, unit==null?"كيلو":unit, price, offer!=null&&offer));
                }
                showCustomer();
            });
    }

    void seed(){
        products.add(new Product("لحم عجل طازج","كيلو",12.99,true));
        products.add(new Product("دجاج طازج","كيلو",5.99,false));
        products.add(new Product("لحم غنم","كيلو",14.99,false));
        products.add(new Product("لحم مفروم","كيلو",10.99,true));
    }

    void base(String title){
        LinearLayout main=new LinearLayout(this);
        main.setOrientation(LinearLayout.VERTICAL);
        main.setBackgroundColor(Color.WHITE); main.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);

        TextView head=tv(title,25,true);
        head.setTextColor(Color.WHITE); head.setGravity(Gravity.CENTER);
        head.setBackgroundColor(RED);
        main.addView(head,new LinearLayout.LayoutParams(-1,dp(62)));

        if (title.contains("مركز اللحوم")) {
            ImageView logo = new ImageView(this);
            logo.setImageResource(com.lahmshop.app.R.drawable.logo);
            logo.setScaleType(ImageView.ScaleType.CENTER_CROP);
            logo.setPadding(dp(12),dp(12),dp(12),dp(12));
            main.addView(logo,new LinearLayout.LayoutParams(-1,dp(270)));

            TextView addr=tv("📍 سوريا — دمشق — ببيلا",17,true);
            addr.setGravity(Gravity.CENTER);
            main.addView(addr,new LinearLayout.LayoutParams(-1,dp(45)));

            TextView contact=tv("📞 0960987637 — أبو موفق    |    📞 0944483343 — أبو محمد حسان",15,true);
            contact.setGravity(Gravity.CENTER);
            main.addView(contact,new LinearLayout.LayoutParams(-1,dp(55)));
        }

        list=new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL); list.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        list.setPadding(dp(12),dp(10),dp(12),dp(20));

        ScrollView sc=new ScrollView(this); sc.addView(list);
        main.addView(sc,new LinearLayout.LayoutParams(-1,0,1));

        LinearLayout nav=new LinearLayout(this);
        nav.setPadding(dp(8),dp(5),dp(8),dp(5));
        Button home=new Button(this); home.setText("العروض");
        Button admin=new Button(this); admin.setText("الإدارة 🔐");
        nav.addView(home,new LinearLayout.LayoutParams(0,dp(58),1));
        nav.addView(admin,new LinearLayout.LayoutParams(0,dp(58),1));
        home.setOnClickListener(v->showCustomer());
        admin.setOnClickListener(v->showAdminLogin());
        main.addView(nav);
        setContentView(main);
    }

    void showCustomer(){
        base("🥩  مركز اللحوم ببيلا");
        TextView offer=tv("🔥 عروض اليوم",22,true);
        offer.setTextColor(RED); list.addView(offer);

        for(Product p:products){
            LinearLayout card=new LinearLayout(this);
            card.setOrientation(LinearLayout.VERTICAL);
            card.setPadding(dp(12),dp(10),dp(12),dp(10));
            card.setBackgroundColor(LIGHT);

            TextView n=tv(p.name,19,true);
            TextView price=tv(String.format(Locale.US,"%.2f",p.price)+" / "+p.unit,18,true);
            price.setTextColor(RED);

            if(p.offer){
                TextView o=tv("🔥 عرض اليوم",15,true);
                o.setTextColor(Color.rgb(0,120,60));
                card.addView(o);
            }
            card.addView(n); card.addView(price);
            list.addView(card,new LinearLayout.LayoutParams(-1,dp(115)));
            Space sp=new Space(this); list.addView(sp,new LinearLayout.LayoutParams(1,dp(8)));
        }

        TextView info=tv("الأسعار والعروض قابلة للتحديث من لوحة الإدارة.\\nالعنوان: سوريا — دمشق — ببيلا\\nللتواصل: 0960987637 أبو موفق | 0944483343 أبو محمد حسان",14,false);
        info.setGravity(Gravity.CENTER); list.addView(info);
    }

    void showAdminLogin(){
        LinearLayout box=new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        EditText email=new EditText(this); email.setHint("البريد الإلكتروني للإدارة");
        EditText pass=new EditText(this); pass.setHint("كلمة المرور");
        pass.setInputType(0x00000081);
        box.addView(email); box.addView(pass);

        new AlertDialog.Builder(this).setTitle("دخول الإدارة")
            .setView(box)
            .setPositiveButton("دخول",(d,w)->{
                auth.signInWithEmailAndPassword(
                    email.getText().toString().trim(),
                    pass.getText().toString()
                ).addOnSuccessListener(r -> {
                    checkAdminAndOpen();
                }).addOnFailureListener(err ->
                    Toast.makeText(this,"بيانات الدخول غير صحيحة",Toast.LENGTH_SHORT).show()
                );
            }).setNegativeButton("إلغاء",null).show();
    }

    void checkAdminAndOpen(){
        if(auth.getCurrentUser()==null) return;
        String uid=auth.getCurrentUser().getUid();
        db.collection("users").document(uid).get().addOnSuccessListener(d -> {
            Boolean admin=d.getBoolean("admin");
            if(Boolean.TRUE.equals(admin)) showAdmin();
            else {
                auth.signOut();
                Toast.makeText(this,"هذا الحساب ليس حساب إدارة",Toast.LENGTH_SHORT).show();
            }
        });
    }

    void showAdmin(){
        base("🔐 لوحة إدارة لحمتنا");
        list.addView(tv("عدّل الأسعار والعروض من هنا",19,true));
        for(Product p:products){
            LinearLayout row=new LinearLayout(this);
            row.setOrientation(LinearLayout.VERTICAL);
            row.setPadding(dp(8),dp(8),dp(8),dp(8));

            EditText name=new EditText(this); name.setText(p.name);
            EditText price=new EditText(this); price.setText(String.format(Locale.US,"%.2f",p.price));
            price.setInputType(2|8192);
            CheckBox offer=new CheckBox(this); offer.setText("عرض اليوم"); offer.setChecked(p.offer);

            Button save=new Button(this); save.setText("حفظ");
            save.setOnClickListener(v->{
                try{
                    String newName=name.getText().toString().trim();
                    double newPrice=Double.parseDouble(price.getText().toString());
                    boolean newOffer=offer.isChecked();
                    db.collection("products").document(p.id).set(new HashMap<String,Object>() {{
                        put("name",newName); put("unit",p.unit); put("price",newPrice); put("offer",newOffer);
                    }}).addOnSuccessListener(x ->
                        Toast.makeText(this,"تم الحفظ وتحديث السعر عند الزبائن",Toast.LENGTH_SHORT).show()
                    ).addOnFailureListener(x ->
                        Toast.makeText(this,"تعذر الحفظ",Toast.LENGTH_SHORT).show()
                    );
                }catch(Exception e){
                    Toast.makeText(this,"السعر غير صحيح",Toast.LENGTH_SHORT).show();
                }
            });

            row.addView(tv("المنتج",14,true)); row.addView(name);
            row.addView(tv("السعر",14,true)); row.addView(price);
            row.addView(offer); row.addView(save);
            Button del=new Button(this); del.setText("حذف المنتج");
            del.setOnClickListener(v -> new AlertDialog.Builder(this)
                .setTitle("حذف المنتج؟").setMessage(p.name)
                .setPositiveButton("حذف",(d,w)->db.collection("products").document(p.id).delete())
                .setNegativeButton("إلغاء",null).show());
            row.addView(del);
            list.addView(row);
        }

        Button add=new Button(this); add.setText("＋ إضافة منتج");
        add.setOnClickListener(v->addProduct());
        list.addView(add);
        Button logout=new Button(this); logout.setText("تسجيل الخروج");
        logout.setOnClickListener(v -> { auth.signOut(); showCustomer(); });
        list.addView(logout);
    }

    void addProduct(){
        LinearLayout box=new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        EditText n=new EditText(this); n.setHint("اسم المنتج");
        EditText p=new EditText(this); p.setHint("السعر");
        p.setInputType(2|8192);
        box.addView(n); box.addView(p);
        new AlertDialog.Builder(this).setTitle("منتج جديد").setView(box)
            .setPositiveButton("إضافة",(d,w)->{
                try{
                    String newName=n.getText().toString().trim();
                    double newPrice=Double.parseDouble(p.getText().toString());
                    String id=db.collection("products").document().getId();
                    db.collection("products").document(id).set(new HashMap<String,Object>() {{
                        put("name",newName); put("unit","كيلو"); put("price",newPrice); put("offer",false);
                    }}).addOnSuccessListener(x -> showAdmin());
                }catch(Exception e){ Toast.makeText(this,"البيانات غير صحيحة",Toast.LENGTH_SHORT).show(); }
            }).setNegativeButton("إلغاء",null).show();
    }

    static class Product{
        String id,name,unit; double price; boolean offer;
        Product(String n,String u,double p,boolean o){id="local_"+System.currentTimeMillis();name=n;unit=u;price=p;offer=o;}
        Product(String i,String n,String u,double p,boolean o){id=i;name=n;unit=u;price=p;offer=o;}
    }
}
