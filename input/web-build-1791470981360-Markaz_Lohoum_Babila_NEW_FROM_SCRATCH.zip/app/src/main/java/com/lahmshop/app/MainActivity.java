package com.lahmshop.app;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.firestore.*;
import java.util.*;

public class MainActivity extends AppCompatActivity {
    LinearLayout root, productsBox;
    EditText name, price;
    Spinner category;
    final String[] cats = {"جاج","غنم","عجل","العروض"};
    FirebaseFirestore db;

    int dp(float v){ return (int)(v*getResources().getDisplayMetrics().density+0.5f); }
    TextView tv(String s, float size){
        TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setPadding(dp(12),dp(10),dp(12),dp(10)); t.setGravity(Gravity.CENTER);
        return t;
    }
    Button btn(String s){ Button b=new Button(this); b.setText(s); return b; }

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        db=FirebaseFirestore.getInstance();
        build();
        loadProducts();
    }

    void build(){
        ScrollView sv=new ScrollView(this);
        root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(dp(12),dp(12),dp(12),dp(12)); root.setGravity(Gravity.CENTER_HORIZONTAL);
        sv.addView(root);

        TextView title=tv("مركز اللحوم ببيلا",28); title.setTypeface(null,1); root.addView(title);
        TextView info=tv("سوريا دمشق – ببيلا\nلحم خروف وعجل ودجاج طازج بشكل يومي\nبإدارة أبو محمد حسان",16); root.addView(info);

        LinearLayout contacts=new LinearLayout(this); contacts.setOrientation(LinearLayout.HORIZONTAL);
        Button w1=btn("واتساب أبو موفق"); w1.setOnClickListener(v->wa("0960987637"));
        Button w2=btn("واتساب أبو محمد حسان"); w2.setOnClickListener(v->wa("0944483343"));
        contacts.addView(w1,new LinearLayout.LayoutParams(0,-2,1)); contacts.addView(w2,new LinearLayout.LayoutParams(0,-2,1)); root.addView(contacts);

        TextView admin=tv("لوحة الإدارة",22); admin.setTypeface(null,1); root.addView(admin);
        name=new EditText(this); name.setHint("اسم المنتج"); root.addView(name);
        price=new EditText(this); price.setHint("السعر"); price.setInputType(2); root.addView(price);
        category=new Spinner(this); category.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,cats)); root.addView(category);
        Button add=btn("إضافة المنتج"); add.setOnClickListener(v->addProduct()); root.addView(add);

        TextView heading=tv("المنتجات والأسعار",22); heading.setTypeface(null,1); root.addView(heading);
        productsBox=new LinearLayout(this); productsBox.setOrientation(LinearLayout.VERTICAL); root.addView(productsBox);

        setContentView(sv);
    }

    void addProduct(){
        String n=name.getText().toString().trim(), p=price.getText().toString().trim(), c=(String)category.getSelectedItem();
        if(n.isEmpty()||p.isEmpty()){ Toast.makeText(this,"اكتب اسم المنتج والسعر",Toast.LENGTH_SHORT).show(); return; }
        Map<String,Object> m=new HashMap<>(); m.put("name",n); m.put("price",p); m.put("category",c);
        db.collection("products").add(m).addOnSuccessListener(x->{ name.setText(""); price.setText(""); loadProducts(); });
    }

    void loadProducts(){
        if(productsBox==null)return;
        productsBox.removeAllViews();
        db.collection("products").get().addOnSuccessListener(q->{
            for(DocumentSnapshot d:q.getDocuments()){
                String n=d.getString("name"), p=d.getString("price"), c=d.getString("category");
                LinearLayout row=new LinearLayout(this); row.setOrientation(LinearLayout.VERTICAL);
                row.addView(tv(c+" — "+n+" : "+p+" ل.س",18));
                LinearLayout actions=new LinearLayout(this);
                Button a=btn("اطلب واتساب 1"); a.setOnClickListener(v->wa("0960987637"));
                Button b=btn("اطلب واتساب 2"); b.setOnClickListener(v->wa("0944483343"));
                Button del=btn("حذف"); del.setOnClickListener(v->d.getReference().delete().addOnSuccessListener(x->loadProducts()));
                actions.addView(a,new LinearLayout.LayoutParams(0,-2,1)); actions.addView(b,new LinearLayout.LayoutParams(0,-2,1)); actions.addView(del,new LinearLayout.LayoutParams(0,-2,1));
                row.addView(actions); productsBox.addView(row);
            }
        });
    }

    void wa(String number){
        String clean=number.replaceAll("[^0-9]","");
        if(clean.startsWith("0")) clean="963"+clean.substring(1);
        Intent i=new Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/"+clean));
        startActivity(i);
    }
}
