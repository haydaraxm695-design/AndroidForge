package com.kitchencut.app;

import android.app.*;
import android.os.Bundle;
import android.graphics.Color;
import android.content.Context;
import android.view.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    LinearLayout list;
    TextView total;
    ArrayList<Part> parts = new ArrayList<>();

    int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + .5f); }

    TextView label(String s) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(14); t.setPadding(dp(4), dp(4), dp(4), dp(4));
        return t;
    }

    EditText input(String hint) {
        EditText e = new EditText(this);
        e.setHint(hint); e.setTextSize(15); e.setSingleLine(true);
        e.setInputType(2);
        e.setPadding(dp(10), dp(2), dp(10), dp(2));
        return e;
    }

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout main = new LinearLayout(this);
        main.setOrientation(LinearLayout.VERTICAL);
        main.setPadding(dp(16), dp(18), dp(16), dp(16));
        main.setBackgroundColor(Color.WHITE);

        TextView title = label("KitchenCut");
        title.setTextSize(28); title.setTextColor(Color.rgb(45,45,45));
        title.setGravity(Gravity.CENTER);
        main.addView(title, new LinearLayout.LayoutParams(-1, dp(55)));

        TextView sub = label("حاسبة وقائمة قص المطابخ الخشب");
        sub.setGravity(Gravity.CENTER);
        main.addView(sub);

        ScrollView scroll = new ScrollView(this);
        list = new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(list);

        addSection(scroll, "إضافة قطعة");

        EditText name = new EditText(this); name.setHint("اسم القطعة مثل: باب خزانة"); name.setSingleLine();
        EditText length = input("الطول سم");
        EditText width = input("العرض سم");
        EditText qty = input("العدد");
        EditText price = input("سعر المتر²");

        addRow(scroll, name);
        addRow(scroll, length);
        addRow(scroll, width);
        addRow(scroll, qty);
        addRow(scroll, price);

        Button add = new Button(this); add.setText("＋ إضافة إلى قائمة القص");
        add.setOnClickListener(v -> {
            try {
                String n = name.getText().toString().trim();
                if (n.length()==0) n = "قطعة";
                double L = Double.parseDouble(length.getText().toString());
                double W = Double.parseDouble(width.getText().toString());
                int Q = Integer.parseInt(qty.getText().toString());
                double P = Double.parseDouble(price.getText().toString());
                if (L<=0 || W<=0 || Q<=0 || P<0) throw new Exception();
                parts.add(new Part(n,L,W,Q,P));
                refresh();
                name.setText(""); length.setText(""); width.setText(""); qty.setText(""); price.setText("");
            } catch(Exception ex) {
                Toast.makeText(this, "تأكد من إدخال المقاسات والعدد والسعر بشكل صحيح", Toast.LENGTH_LONG).show();
            }
        });
        list.addView(add);

        addSection(scroll, "قائمة القص");
        LinearLayout rows = new LinearLayout(this);
        rows.setOrientation(LinearLayout.VERTICAL);
        list.addView(rows);
        this.rowsContainer = rows;

        total = label("المساحة: 0.00 م²    |    تكلفة الألواح: 0.00");
        total.setTextSize(17); total.setGravity(Gravity.CENTER);
        main.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        main.addView(total);

        Button quote = new Button(this); quote.setText("إنشاء عرض سعر");
        quote.setOnClickListener(v -> showQuote());
        main.addView(quote);

        setContentView(main);
    }

    LinearLayout rowsContainer;

    void addSection(ScrollView s, String text) {
        TextView h = label(text);
        h.setTextSize(19); h.setGravity(Gravity.RIGHT);
        h.setPadding(0, dp(18), 0, dp(8));
        list.addView(h);
    }

    void addRow(ScrollView s, View v) {
        list.addView(v, new LinearLayout.LayoutParams(-1, dp(52)));
    }

    void refresh() {
        rowsContainer.removeAllViews();
        double area=0, cost=0;
        for (Part p: parts) {
            area += p.area(); cost += p.cost();
            TextView r = label(p.name + "  |  " + fmt(p.L) + " × " + fmt(p.W) +
                    " سم  |  عدد " + p.Q + "  |  " + fmt(p.area()) + " م²  |  " + fmt(p.cost()));
            r.setTextSize(15); r.setPadding(dp(8),dp(10),dp(8),dp(10));
            rowsContainer.addView(r);
            View line = new View(this); line.setBackgroundColor(Color.LTGRAY);
            rowsContainer.addView(line, new LinearLayout.LayoutParams(-1,1));
        }
        total.setText("المساحة الإجمالية: " + fmt(area) + " م²    |    تكلفة الألواح: " + fmt(cost));
    }

    String fmt(double x) { return String.format(Locale.US, "%.2f", x); }

    void showQuote() {
        if (parts.size()==0) { Toast.makeText(this,"أضف قطعًا أولًا",Toast.LENGTH_SHORT).show(); return; }
        double material=0;
        for (Part p: parts) material += p.cost();
        double labor=material*.25, profit=(material+labor)*.20, finalPrice=material+labor+profit;
        new AlertDialog.Builder(this)
            .setTitle("عرض سعر — KitchenCut")
            .setMessage("تكلفة الألواح: " + fmt(material) +
                "\nأجور تقديرية: " + fmt(labor) +
                "\nهامش ربح تقديري: " + fmt(profit) +
                "\n----------------\nالسعر المقترح: " + fmt(finalPrice))
            .setPositiveButton("موافق", null).show();
    }

    static class Part {
        String name; double L,W,P; int Q;
        Part(String n,double l,double w,int q,double p){name=n;L=l;W=w;Q=q;P=p;}
        double area(){return L*W*Q/10000.0;}
        double cost(){return area()*P;}
    }
}
